export const environment = {
  production: false,
  usuariosApiUrl: 'http://localhost:44352/api'
}