import { UsuarioService } from './../../services/usuario.service';
import { Usuario } from '../../interfaces/usuario';
import { ErrorMsgComponent } from '../../compartilhado/error-msg/error-msg.component';
import { Component, OnInit, ViewChild } from '@angular/core';


@Component({
  selector: 'app-lista-usuario',
  templateUrl: './lista-usuario.component.html',
  styleUrls: ['./lista-usuario.component.css']
})
export class ListaUsuarioComponent implements OnInit {
  public usuarios: Usuario[];
  @ViewChild(ErrorMsgComponent) errorMsgComponent: ErrorMsgComponent;

  constructor(private usuarioService: UsuarioService) { }

  ngOnInit() {
    this.getListausuarios();
  }

  getListausuarios() {
    this.usuarioService.getListaUsuarios()
      .subscribe((usuarios: Usuario[]) => {
        this.usuarios = usuarios;
      }, () => { this.errorMsgComponent.setError('Falha ao buscar usuarios.'); });
  }

  deletausuario(id: number) {
    this.usuarioService.deletaUsuario(id)
      .subscribe(() => {
        this.getListausuarios();
      }, () => { this.errorMsgComponent.setError('Falha ao deletar usuario.'); });
  }

  existemusuarios(): boolean {
    return this.usuarios && this.usuarios.length > 0;
  }

}
