import { UsuarioService } from './../../services/usuario.service';
import { ErrorMsgComponent } from './../../compartilhado/error-msg/error-msg.component';
import { Usuario } from './../../interfaces/usuario';
import { Component,  ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-editar-usuario',
  templateUrl: './editar-usuario.component.html',
  styleUrls: ['./editar-usuario.component.css']
})
export class EditarUsuarioComponent {
  public usuario: Usuario[];
  @ViewChild(ErrorMsgComponent) errorMsgComponent: ErrorMsgComponent;

  constructor(private usuarioService: UsuarioService,
              private activatedRoute: ActivatedRoute,
              private router: Router) {
      this.getUsuario(this.activatedRoute.snapshot.params.id);
    }

    getUsuario(id: number) {
      this.usuarioService.getUsuario(id)
        .subscribe((usuario: Usuario[]) => {
          this.usuario = usuario;
        }, () => { this.errorMsgComponent.setError('Falha ao buscar usuario.'); });
    }

    atualizaUsuario(usuario: Usuario) {
      this.usuarioService.atualizaUsuario(usuario)
        .subscribe(
          () => { this.router.navigateByUrl('/'); },
          () => { this.errorMsgComponent.setError('Falha ao atualizar usuário.'); });
    }


}
