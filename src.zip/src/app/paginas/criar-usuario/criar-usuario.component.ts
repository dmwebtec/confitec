import { Usuario } from './../../interfaces/usuario';
import { ErrorMsgComponent } from './../../compartilhado/error-msg/error-msg.component';
import { UsuarioService } from './../../services/usuario.service';
import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-criar-usuario',
  templateUrl: './criar-usuario.component.html',
  styleUrls: ['./criar-usuario.component.css']
})
export class CriarUsuarioComponent  {
  @ViewChild(ErrorMsgComponent) errorMsgComponent: ErrorMsgComponent;
  constructor(private usuarioService: UsuarioService, private router: Router) { }

  addUsuario(usuario: Usuario) {
    this.usuarioService.addUsuario(usuario)
      .subscribe(
        () => { this.router.navigateByUrl('/'); },
        () => { this.errorMsgComponent.setError('Falha ao incluir usurio.'); });
  }
 
}
