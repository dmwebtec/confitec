import { EditarUsuarioComponent } from './paginas/editar-usuario/editar-usuario.component';
import { CriarUsuarioComponent } from './paginas/criar-usuario/criar-usuario.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ListaUsuarioComponent } from './paginas/lista-usuario/lista-usuario.component';

const routes: Routes = [
  { path: '', component: ListaUsuarioComponent },
  { path: 'usuario/criar', component: CriarUsuarioComponent },
  { path: 'usuario/editar/:id', component: EditarUsuarioComponent },
  { path: '**', redirectTo: ''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
