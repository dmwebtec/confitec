import { ErrorMsgComponent } from './compartilhado/error-msg/error-msg.component';
import { Component, ViewChild, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  titulo = 'Confitec - CRUD de usuarios com consumo de APi';
  @ViewChild(ErrorMsgComponent) errorMsgComponent: ErrorMsgComponent;

  ngOnInit(){
    this.errorMsgComponent.setError('Mensagem de erro');
  }

  // constructor() {
  //   this.errorMsgComponent.setError('Mensagem de erro');
  // }
}
