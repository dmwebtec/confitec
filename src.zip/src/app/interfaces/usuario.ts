type escolaridade = 'INFANTIL' | 'FUNDAMENTAL' | 'MEDIO' | 'SUPERIOR';
export interface Usuario {
    id: number;
    nome: string;
    sobrenome: string;
    email: string;
    datanascimento: number;
    escolaridade: escolaridade;
}
