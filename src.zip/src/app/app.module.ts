import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ErrorMsgComponent } from './compartilhado/error-msg/error-msg.component';
import { ListaUsuarioComponent } from './paginas/lista-usuario/lista-usuario.component';
import { FormUsuarioComponent } from './compartilhado/form-usuario/form-usuario.component';
import { CriarUsuarioComponent } from './paginas/criar-usuario/criar-usuario.component';
import { EditarUsuarioComponent } from './paginas/editar-usuario/editar-usuario.component';

@NgModule({
  declarations: [
    AppComponent,
    ErrorMsgComponent,
    ListaUsuarioComponent,
    FormUsuarioComponent,
    CriarUsuarioComponent,
    EditarUsuarioComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
