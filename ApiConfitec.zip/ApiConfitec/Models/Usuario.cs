﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace ApiConfitec.Models
{
    [Table("Usuarios")]
    public class Usuario
    {
        
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome deve ser preenchido.")]
        [Index("NomeIdx", IsUnique =  false)]
        [MaxLength(50, ErrorMessage = "O primeiro nome só pode conter até 50 caracteres.")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O sobre nome deve ser preenchido.")]
        [MaxLength(100, ErrorMessage = "O sobre nome só pode conter até 100 caracteres.")]
        public string SobreNome { get; set; }

        [Required(ErrorMessage = "O email deve ser preenchido.")]
        [EmailAddress(ErrorMessage = "email inválido")]
        public string Email { get; set; }

        [Required(ErrorMessage = "O date de nascimento deve ser preenchido.")]
        //validar data , deve ser maio que data atual e válida
        public DateTime DataNascimento { get; set; }

        [Required(ErrorMessage = "A escolaridade deve ser preenchida.")]
        [JsonConverter(typeof(StringEnumConverter))]
        public Escolaridade Escolaridade { get; set; }
    }
}