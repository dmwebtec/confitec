﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ApiConfitec.Models
{
    public class UsuariosContext : DbContext
    {
        public UsuariosContext() : base("Usuario")
        {
            Database.Log = d => System.Diagnostics.Debug.WriteLine(d);
        }
        public DbSet<Usuario> Usuarios { get; set; } 

    }
}