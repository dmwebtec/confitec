﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiConfitec.Models
{
    public enum Escolaridade
    {
        Infantil,
        Fundamental,
        Médio,
        Superior
    }
}