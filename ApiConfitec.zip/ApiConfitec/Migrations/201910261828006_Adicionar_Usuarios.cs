namespace ApiConfitec.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Adicionar_Usuarios : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Usuarios",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Nome = c.String(maxLength: 50),
                        SobreNome = c.String(maxLength: 100),
                        Email = c.String(),
                        DataNascimento = c.DateTime(nullable: false),
                        Escolaridade = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Usuarios");
        }
    }
}
