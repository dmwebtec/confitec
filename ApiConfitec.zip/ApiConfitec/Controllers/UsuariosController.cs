﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ApiConfitec.Models;

namespace ApiConfitec.Controllers
{
    public class UsuariosController : ApiController
    {
        private UsuariosContext db = new UsuariosContext();

        // GET: api/Usuarios
        public IHttpActionResult GetUsuarios(int pagina = 1, int tamanhoPagina = 10)
        {
            if (pagina <= 0 || tamanhoPagina <= 0)
            {
                return BadRequest("Os parâmetros pagina e tamanhoPagina devem ser maiores que zeros.");
            }
            if (tamanhoPagina > 10)
            {
                return BadRequest("O tamanho máximo de página permitido é 10.");
            }

            int totalPaginas = (int)Math.Ceiling(db.Usuarios.Count() / Convert.ToDecimal(tamanhoPagina));

            if (pagina > totalPaginas)
            {
                return BadRequest("A página solicitada não existe.");
            }

            System.Web.HttpContext.Current.Response.AddHeader("X-Pagination-TotalPages", totalPaginas.ToString());

            if (pagina > 1)            
                System.Web.HttpContext.Current.Response.AddHeader("X-Pagination-PreviousPage",
                    Url.Link("DefaultApi", new { pagina = pagina - 1, tamanhoPagina = tamanhoPagina }));

            if (pagina < totalPaginas)
                System.Web.HttpContext.Current.Response.AddHeader("X-Pagination-NextPage",
                    Url.Link("DefaultApi", new { pagina = pagina + 1, tamanhoPagina = tamanhoPagina }));


            var usuarios = db.Usuarios.OrderBy(c => c.Nome).Skip(tamanhoPagina * (pagina - 1)).Take(tamanhoPagina);
            return Ok(usuarios);
        }

        // GET: api/Usuarios/5
        [ResponseType(typeof(Usuario))]
        public IHttpActionResult GetUsuario(int id)
        {
            if (id <= 0)
                return BadRequest("O Id deve ser um número maior que zero");

            Usuario usuario = db.Usuarios.Find(id);
            if (usuario == null)
            {
                return NotFound();
            }

            return Ok(usuario);
        }

        // PUT: api/Usuarios/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutUsuario(int id, Usuario usuario)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != usuario.Id)
            {
                return BadRequest("o id informado na url é diferente do id informado no corpo da requisição");
            }

            DateTime dtNas = usuario.DataNascimento;
            DateTime dataHoje = DateTime.Now;
            if (dtNas > dataHoje)
            {
                return BadRequest("A data de nascimento não pode ser maior que data de hoje.");
            }

            db.Entry(usuario).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UsuarioExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Usuarios
        [ResponseType(typeof(Usuario))]
        public IHttpActionResult PostUsuario(Usuario usuario)
        {
            if (!ModelState.IsValid)
            {                
                return BadRequest(ModelState);
            }

            DateTime dtNas = usuario.DataNascimento;
            DateTime dataHoje = DateTime.Now;
            if (dtNas > dataHoje )
            {
                return BadRequest("A data de nascimento não pode ser maior que data de hoje.");
            }

            db.Usuarios.Add(usuario);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = usuario.Id }, usuario);
        }

        // DELETE: api/Usuarios/5
        [ResponseType(typeof(Usuario))]
        public IHttpActionResult DeleteUsuario(int id)
        {
            if (id <= 0)
                return BadRequest("O id deve ser maior que zero.");

            Usuario usuario = db.Usuarios.Find(id);

            if (usuario == null)
            {
                return NotFound();
            }

            db.Usuarios.Remove(usuario);
            db.SaveChanges();

            return Ok(usuario);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool UsuarioExists(int id)
        {
            return db.Usuarios.Count(e => e.Id == id) > 0;
        }
    }
}